public class SegmentTree {
    int[] tree;
    int n;

    SegmentTree(int[] arr) {
        n = arr.length;
        tree = new int[4 * n];
        build(arr, 1, 0, n - 1);
    }

    void build(int[] arr, int node, int start, int end) {
        if (start == end) tree[node] = arr[start];
        else {
            int mid = (start + end) / 2;
            build(arr, node * 2, start, mid);
            build(arr, node * 2 + 1, mid + 1, end);
            tree[node] = tree[node * 2] + tree[node * 2 + 1];
        }
    }

    int query(int node, int start, int end, int l, int r) {
        if (r < start || l > end) return 0;
        if (l <= start && end <= r) return tree[node];

        int mid = (start + end) / 2;
        return query(node * 2, start, mid, l, r)
                + query(node * 2 + 1, mid + 1, end, l, r);
    }

    public static void main(String[] args) {
        int[] arr = {10, 20, 30, 40, 50};
        SegmentTree st = new SegmentTree(arr);

        System.out.println("Sum from index 1 to 3 = "
                + st.query(1, 0, arr.length - 1, 1, 3));
    }
}